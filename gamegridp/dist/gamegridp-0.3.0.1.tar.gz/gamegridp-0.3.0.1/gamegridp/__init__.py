import logging
import pygame
logging.getLogger(__name__).addHandler(logging.NullHandler())
