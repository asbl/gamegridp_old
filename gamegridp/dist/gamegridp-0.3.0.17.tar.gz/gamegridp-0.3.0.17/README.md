# gamegridp

Gamegridp ist ein Klon von gamegrid/greenfoot für Python. 

Das Framework steckt zur Zeit noch in den Kinderschuhen und wird in nächster Zeit weiterentwickelt.

Github: https://github.com/asbl/gamegridp
Dokumentation: https://github.com/asbl/gamegridp/wiki
