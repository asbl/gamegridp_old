# gamegridp

Gamegridp ist ein Klon von gamegrid/greenfoot für Python. 

Das Framework steckt zur Zeit noch in den Kinderschuhen und wird in nächster Zeit weiterentwickelt.
